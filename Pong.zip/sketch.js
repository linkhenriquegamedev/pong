//determina os valores da criação da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 13;
let raio = diametro/2;

//determina a velocidade da bolinha
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

//determina os valores da criação da minha raquete
let xMinhaRaquete = 1;
let yMinhaRaquete = 150;
let comprimentoRaquete = 10;
let alturaRaquete = 90;
let xOponenteRaquete = 585;
let yOponenteRaquete = 150;
let velocidadeYOponente;
let colidiu = false;

//determinar os valores dos pontos
let meusPontos = 0;
let pontosDoOponente = 0;

//determinar som
let trilha;
let ponto;
let raquetada;

//dificuldade do jogo
let chanceDeErrar = 0;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  criarBolinha();
  movimentarBolinha();
  delimitarFronteira();
  criarRaquete(xMinhaRaquete, yMinhaRaquete);
  criarRaquete(xOponenteRaquete, yOponenteRaquete);
  movimentarMinhaRaquete();
  movimentarRaqueteOponente();
  VerificaColisaoRaquete(xMinhaRaquete, yMinhaRaquete);
  VerificaColisaoRaquete(xOponenteRaquete, yOponenteRaquete);
  IncluirPlacar();
  IncluirPontos();
  BolinhaNaoFicaPresa();
}

function criarBolinha(){
  circle(xBolinha, yBolinha, diametro);
  //circle(width/2, height/2, diametro); - Deixa a bolinha no
    //centro da tela
}

function criarRaquete(x, y){
  rect(x, y, comprimentoRaquete, alturaRaquete);
}

function movimentarBolinha(){
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function delimitarFronteira(){
  if (xBolinha + raio> width || xBolinha - raio < 0){
    velocidadeXBolinha *= -1;
  }
  
  if (yBolinha + raio > height || yBolinha - raio < 0){
    velocidadeYBolinha *= -1;
  }
}

function movimentarMinhaRaquete(){
  if(keyIsDown(UP_ARROW)){
       yMinhaRaquete -= 10;
  }
  if(keyIsDown(DOWN_ARROW)){
       yMinhaRaquete += 10;
  }
}

function movimentarRaqueteOponente(){
  /*if(keyIsDown(87)){
       yOponenteRaquete -= 10;
  }
  if(keyIsDown(83)){
       yOponenteRaquete += 10;
  }*/
  velocidadeYOponente = yBolinha - yOponenteRaquete - comprimentoRaquete / 2 - 30;
  yOponenteRaquete += velocidadeYOponente + chanceDeErrar;
  ChanceDeErroDoOponente();
}

function VerificaColisaoRaquete(x, y){
  colidiu = collideRectCircle(x, y, comprimentoRaquete, alturaRaquete, xBolinha, yBolinha, raio);
  if(colidiu) {
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}

function ChanceDeErroDoOponente(){
  if (pontosDoOponente > meusPontos){
    chanceDeErrar += 1
    if (chanceDeErrar >= 40){
      chanceDeErrar = 40
    }
  } else {
    chanceDeErrar -= 1;
    if (chanceDeErrar <= 35){
      chanceDeErrar = 35;
    }
  }
}

function IncluirPlacar(){
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0));
  rect(150, 10, 40, 20);
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(255, 140, 0));
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosDoOponente, 470, 26);
}

function IncluirPontos(){
  if (xBolinha > 590){
    meusPontos += 1;
    ponto.play();
  }
  if (xBolinha < 10){
    pontosDoOponente += 1;
    ponto.play();
  }
  
}

function BolinhaNaoFicaPresa(){
  if (xBolinha - raio < 0){
    console.log('bolinha ficou presa');
    xBolinha = 23;
    }
  
  if (xBolinha + raio > 600){
    console.log('bolinha ficou presa');
    xBolinha = 580;
    }
  }